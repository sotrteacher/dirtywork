/* descargarUnaversionDeMTX.c */
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>  /*atoi()*/
#include <stdio.h>
#include <signal.h>
#include <wait.h>

int 
main (int argc, char *argv[]) 
{
  int i,linf,lsup;      /*limite inferior, limite superior*/  
  pid_t childpid;
  char cad[512];
  if(argc!=2){
    printf("FORMA DE USO: ./%s <url> <numJPGinicial> <numJPGfinal>",
           argv[0]);
    printf("Por ejemplo: ./%s https://raw.githubusercontent.com/sotrteacher/dirtywork/master/MTX5_1\n",argv[0]);
    return 0;
  }
    sprintf(cad,"%s.tar",argv[1]);
    printf("Cadena de URL:\n%s\n",cad);
    if((childpid=fork())==0){/*Child's code*/
        execl("/usr/bin/wget","magic wget",cad,NULL);
    }else{
      waitpid(childpid,0,0);
    }

  return EXIT_SUCCESS;
}/*end main()*/

