/** descargarUnaversionDeMTX.c - Programa para descargar 
 archivos desde el repositorio
 https://github.com/sotrteacher/dirtywork
 El programa utiliza el paradigma fork-exec. El proceso 
 padre crea un proceso hijo haciendo la llamada al 
 sistema fork(), el proceso hijo cambia su imagen de 
 modo usuario por la imagen /usr/bin/wget usando la 
 llamada al sistema execl(), tambi\'en en la misma 
 llamada a execl(), se pasa el argumento para la imagen 
 /usr/bin/wget a trav\'es de la cadena de caracteres 
 cad, que en este ejemplo contiene la concatenaci\'on 
 de la cadena
 https://raw.githubusercontent.com/sotrteacher/dirtywork/master/
 con el nombre de un archivo que uno quiera descargar
 del repositorio https://github.com/sotrteacher/dirtywork
 El nombre del archivo a descargar se debe pasar como 
 argumento en la l\'inea de comandos al ejecutar este 
 programa.
*/
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>  /*atoi()*/
#include <stdio.h>
#include <signal.h>
#include <wait.h>

int 
main (int argc, char *argv[]) 
{
  pid_t childpid;
  char cad[512];
  if(argc!=2){
    printf("FORMA DE USO: %s <filename>\n",argv[0]);
    printf("Por ejemplo: %s MTX5_1.tar\n",argv[0]);
    return 0;
  }
  sprintf(cad,"https://raw.githubusercontent.com/sotrteacher/dirtywork/master/%s",argv[1]);
  printf("Cadena de URL:\n%s\n",cad);
  if((childpid=fork())==0){/*Child's code*/
      execl("/usr/bin/wget","magic wget",cad,NULL);
  }else{
    waitpid(childpid,0,0);
  }

  return EXIT_SUCCESS;
}/*end main()*/

