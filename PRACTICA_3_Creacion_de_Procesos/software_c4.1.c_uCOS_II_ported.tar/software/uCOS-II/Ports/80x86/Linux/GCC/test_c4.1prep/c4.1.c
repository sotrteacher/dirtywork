/**** c4.1.c file: compute matrix sum by tasks ***/
/**
 * Este programa es un port a uCOS-II del ejemplo c4.1.c del siguiente
 * libro: Systems Programming in Unix/Linux, K.C. Wang, editorial 
 * Springer Nature, 2018. Chapter 4 Concurrent Programming, page 147.
 * ISBN: 978-3-319-92428-1 ISBN: 978-3-319-92429-8 (eBook).
 *
 *   make -f makefile.lin
 *
 * Or:
   gcc -D__LINUX__ -I/software/uCOS-II/source 
   -I/software/uCOS-II/Ports/80x86/Linux/GCC/src c4.1.c 
   /software/uCOS-II/source/uCOS_II.c 
   /software/uCOS-II/Ports/80x86/Linux/GCC/src/pc.c 
   /software/uCOS-II/Ports/80x86/Linux/GCC/src/os_cpu_c.c  
   -o c4.1
 *
 */
#include <string.h>  /*2021.04.29*/
#include "includes.h"
//#define NDEBUG
//#include <assert.h>
#define N 4
int A[N][N], sum[N];
INT16U count;       /* contador para identificar cu\'ando las tareas sumadoras han terminado de sumar */ 

//OS_EVENT 	  *semMat;   /* Sem\'aforo para controlar el acceso a A y a sum */
OS_EVENT      *sem_finish;   /* Sema\'aforo para controlar el acceso a count */

#define  TASK_STK_SIZE                 512       /* Size of each task's stacks (# of WORDs)            */
#define  N_TASKS                         N       /* Number of identical tasks                          */

OS_STK        TaskStk[N_TASKS][TASK_STK_SIZE];        /* Tasks stacks                                  */
OS_STK        TaskStartStk[TASK_STK_SIZE];
INT8U         TaskData[N_TASKS];                      /* Parameters to pass to each task               */
INT8U         TaskPrio[N_TASKS];                      /* Priorities for each task                      */

void  TaskStart(void *data);                          /* Function prototype of Startup task            */
void  func(void *arg);                                /* Function shared by four tasks                 */



int main (int argc, char *argv[])
{
  // Display a banner.
  printf("##### uCOS-II V%4.2f Port V%4.2f for LINUX #####\n", ((FP32)OSVersion())/100, ((FP32)OSPortVersion())/100);
  OSInit();                                              /* Initialize uC/OS-II                      */

  printf("Main: create first task\n", N);
  OSTaskCreate(TaskStart,  
               (void *)0,
               &TaskStartStk[TASK_STK_SIZE - 1],
               0);                                       /* Task priority = 0                        */
  // Start multitasking.
  OSStart();                                             //Calling sequence -->OSTaskSwHook-->OSStartHighRdy
                 
  /* NEVER EXECUTED */
  printf("main(): We should never execute this line\n");
  return 0;
}/*end main()*/


void  TaskStart (void *pdata)
{
  INT16S     key;
  pdata = pdata;                                      /* Prevent compiler warning                 */
  
  INT16S i, j, r, total = 0;				//Creación e impresión 
  printf("TaskStart: initialize A matrix\n");		//de la matriz que se va a computar
  for (i=0; i<N; i++){
    sum[i] = 0;
    for (j=0; j<N; j++){
      A[i][j] = i*N + j + 1;
      printf("%4d ", A[i][j]);
    }
    printf("\n");
  }
  count = 0;			// Inicialización de count
//  semMat = OSSemCreate(1);	//Creación de un semaforos
  sem_finish = OSSemCreate(1);
  //TaskStartCreateTasks();                           /* Create all the application tasks         */
  for (i = 0; i < N; i++) {                        /* Create N identical tasks           */
    TaskData[i] = '0' + i;                         /* Each task will display its own letter    */
    OSTaskCreate(func, (void *)&TaskData[i], &TaskStk[i][TASK_STK_SIZE - 1], (INT8U) (i + 1));
    printf("Tarea n\\'umero %c creada\n",TaskData[i]);
  }
  
  OSStatInit();                                          /* Initialize uC/OS-II's statistics         */
  // Esperar a que terminen todas las tareas
  //INT8U err;
  //INT16U  temp_count = 0;
  while(count < N) ;/*
  {
      OSSemPend(sem_finish, 0, &err);
      temp_count = count;
      OSSemPost(sem_finish);
      OSTimeDlyHMSM(0,0,0,1);
  }*/

  // Impresi\'on del valor final
  printf("TaskStart: compute and print total sum: ");
  for (i=0; i<N; i++)
      total += sum[i];
  printf("total = %d\n", total);

  for (;;) {
    //TaskStartDisp();
    if (PC_GetKey(&key) == TRUE) {                     /* See if key has been pressed              */
        if (key == 0x1B) {                             /* Yes, see if it's the ESCAPE key          */
            exit(0);                                   /*      Return to DOS                       */
        }
    }
    OSCtxSwCtr = 0;
    OSTimeDlyHMSM(0, 0, 1, 0);                         /* Wait one second                          */
  }
}/*end TaskStart()*/


//void *func(void *arg) // threads function
void func(void *arg) // Tasks function
{
  INT16U j;
  INT8U err;
  INT16U row;
  char numTarea = *(char *)arg;
  row=numTarea - '0';
  INT8U tid = *(INT8U *)arg + 1;
  printf("Task %d [%lu] computes sum of row %d\n", row, tid, row);
  for (j=0; j<N; j++)            // compute sum of A[row]in global sum[row]
  {
    sum[row] += A[row][j];
    OSTimeDly(1);
  }
  printf("Task %d [%lu] done: sum[%d] = %d\n",row, tid, row, sum[row]);

  // Aumentar el valor de count
  OSSemPend(sem_finish, 0, &err);
  count +=1;
  OSSemPost(sem_finish);
//  pthread_exit((void*)0);        // thread exit: 0=normal termination
  OSTaskSuspend(OS_PRIO_SELF);
}/*end func()*/


