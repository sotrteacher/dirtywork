/**** C4.1.c file: compute matrix sum by threads ***/
/**
 * Este programa es un port a uCOS-II del ejemplo C4.1 del siguiente
 * libro: Systems Programming in Unix/Linux, K.C. Wang, editorial 
 * Springer Nature, 2018. Chapter 4 Concurrent Programming, page 147.
 * ISBN: 978-3-319-92428-1 ISBN: 978-3-319-92429-8 (eBook).
 *
 * 
 * 
 * Fecha: 29 de abril de 2021
 * Autor: Luna R. Rodrigo
 */

#include "includes.h"


/*
*********************************************************************************************************
*                                               CONSTANTS
*********************************************************************************************************
*/

#define  TASK_STK_SIZE                 512       /* Size of each task's stacks (# of WORDs)            */
#define  N                             4       /* Number of identical tasks y tamaño de matriz        */

/*
*********************************************************************************************************
*                                               VARIABLES
*********************************************************************************************************
*/

OS_STK        TaskStk[N][TASK_STK_SIZE];        /* Tasks stacks                                  */
OS_STK        TaskStartStk[TASK_STK_SIZE];
char          TaskData[N];                      /* Parameters to pass to each task               */
INT16S        A[N][N], sum[N];	  // Matriz A y sum
INT16U		  count;								  // Variable que sirve para identificar cuando el proceso
													  // ha finalizado.
OS_EVENT 	  *semMat;								  // Semaforo para modificar A y sum
OS_EVENT      *sem_finish;						      // Semaforo para modificar la variable count
/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/

        void  func(void *arg);                       /* Function prototypes of tasks                  */
        void  TaskStart(void *data);                  /* Function prototypes of Startup task           */
static  void  TaskStartCreateTasks(void);

/*
*********************************************************************************************************
*                                           MAIN
*********************************************************************************************************
*/

int main(void)
{
    // Display a banner.
    printf("##### uCOS-II V%4.2f Port V%4.2f for LINUX #####\n", ((FP32)OSVersion())/100, ((FP32)OSPortVersion())/100);

     // Initialize uCOS-II.
    OSInit();                    //Calling sequence -->OSInitHookBegin-->OSTaskStkInit-->OSTCBInitHook-->OSTaskCreateHook-->OSInitHookEnd

    // Create the first task
    OSTaskCreate(TaskStart, (void *)0, &TaskStartStk[TASK_STK_SIZE - 1], 0);

    // Start multitasking.
    OSStart();                                                              //Calling sequence -->OSTaskSwHook-->OSStartHighRdy

    /* NEVER EXECUTED */
    printf("main(): We should never execute this line\n");

    return 0;
}

/*
*********************************************************************************************************
*                                              STARTUP TASK
*********************************************************************************************************
*/
void  TaskStart (void *pdata)
{
    pdata = pdata;                                         /* Prevent compiler warning                 */
    
    INT16S i, j, r, total = 0;							//Creación e impresión 
    printf("Main: initialize A matrix\n");				//de la matriz que se va a computar
    for (i=0; i<N; i++){
      sum[i] = 0;
    for (j=0; j<N; j++){
      A[i][j] = i*N + j + 1;
      printf("%4d ", A[i][j]);
      }
      printf("\n");
    }
    count = 0;												// Inicialización de count
    semMat = OSSemCreate(1);								//Creación de un semaforos
    sem_finish = OSSemCreate(1);

    TaskStartCreateTasks();                                /* Create all the application tasks         */

    OSStatInit();                                          /* Initialize uC/OS-II's statistics         */
    
    // Esperar a que terminen todas las tareas
    INT8U err;
    INT16U  temp_count = 0;
    while(temp_count != N)
    {
		OSSemPend(sem_finish, 0, &err);
		temp_count = count;
		OSSemPost(sem_finish);
		OSTimeDlyHMSM(0,0,0,1);
	}
	
	// Impresión del valor final
	printf("Main: compute and print total sum: ");
	for (i=0; i<N; i++)
		total += sum[i];
	printf("total = %d\n", total);
}

/*
*********************************************************************************************************
*                                        Creación de las tareas identicas
*********************************************************************************************************
*/
static  void  TaskStartCreateTasks (void)
{
	INT8U i;
    for (i = 0; i < N; i++) {                        /* Create N identical tasks           */
        TaskData[i] = '0' + i;                             /* Each task will display its own letter    */
        OSTaskCreate(func, (void *)&TaskData[i], &TaskStk[i][TASK_STK_SIZE - 1], (INT8U) (i + 1));
        printf("Tarea Numero %c creada\n",TaskData[i]);
    }
}

/*

*********************************************************************************************************
*                                         Función de Operación de matrices
*********************************************************************************************************
*/
void func(void *arg) // task function
{
  INT16U j;
  INT8U err;
  
  char numTarea;
  numTarea = *(char *)arg;                // get row number from arg
  INT16U row = numTarea - '0';
  printf("Task %c computes sum of row %d\n", numTarea, row);
  for (j=0; j<N; j++)            // compute sum of A[row]in global sum[row]
  {	
	OSSemPend(semMat, 0, &err);
    sum[row] += A[row][j];
    OSSemPost(semMat);
    OSTimeDly(1);
  }
  // Aumentar el valor de count
  OSSemPend(sem_finish, 0, &err);
  count +=1;
  OSSemPost(sem_finish);
  
  printf("Task %c done: sum[%d] = %i\n", numTarea, row, sum[row]);
  OSTaskSuspend(OS_PRIO_SELF);
}/*end func()*/
