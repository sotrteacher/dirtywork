#include <stdio.h>
#include <stdlib.h>
#include "includes.h"
#define SIZE_ARR(a)	(sizeof(a)/sizeof(a[0]))
typedef unsigned int uint;
#define  TASK_STK_SIZE                 512            /* Size of TaskStart's stack (# of WORDs)            */

OS_EVENT *ResourceMutex;
OS_STK        TaskStartStk[TASK_STK_SIZE];
OS_STK    TaskPrio10Stk[1000];
OS_STK    TaskPrio15Stk[1000];
OS_STK    TaskPrio20Stk[1000];
FILE *des;

/*
*********************************************************************************************************
*                                           FUNCTION PROTOTYPES
*********************************************************************************************************
*/
void  TaskStart  (void  *data);                          /* Function prototype of Startup task            */
void  TaskPrio10 (void *pdata);
void  TaskPrio15 (void *pdata);
void  TaskPrio20 (void *pdata);


int main()
{
  // Display a banner.
  printf("##### uCOS-II V%4.2f Port V%4.2f for LINUX #####\n", ((FP32)OSVersion())/100, ((FP32)OSPortVersion())/100);
  OSInit();
  /*Application Initialization*/
  printf("Main: create TaskStart!\n");
  OSTaskCreate(TaskStart, (void *)0, &TaskStartStk[TASK_STK_SIZE - 1], 0);

  OSStart();
  /* NEVER EXECUTED */
  printf("main(): We should never execute this line\n");
  return 0;
}/*end main()*/

void  TaskStart (void *pdata)
{
  INT16S     key;
  INT8U err;
  pdata = pdata;                                      /* Prevent compiler warning                 */
  char device[] = "/dev/scull";

  if ((des = fopen(device,"a")) == NULL) {
    printf("\nTaskStart: NO SE PUDO ABRIR EL DISPOSITIVO %s\n",device);
    printf("REVISE SI EXISTE EL DISPOSITIVO CON: ls -hgo /dev | grep scull\n");
    printf("Y SI ESTA CARGADO EL MODULO scull CON: lsmod | grep scull\n");
    exit(1);
  }
  ResourceMutex = OSMutexCreate(9, &err);
  
  OSTaskCreate(TaskPrio10, (void*)0, &TaskPrio10Stk[999], 10);
  OSTaskCreate(TaskPrio15, (void*)0, &TaskPrio15Stk[999], 15);
  OSTaskCreate(TaskPrio20, (void*)0, &TaskPrio20Stk[999], 20);
  OSStatInit();                                      /* Initialize uC/OS-II's statistics         */

  for (;;) {
    if (PC_GetKey(&key) == TRUE) {                     /* See if key has been pressed              */
       if (key == 0x1B) {                              /* Yes, see if it's the ESCAPE key          */
           exit(0);                                    /*      Return to DOS                       */
       }
    }
    OSCtxSwCtr = 0;
    OSTimeDlyHMSM(0, 0, 1, 0);                         /* Wait one second                          */
  }
}/*end TaskStart()*/
  

void TaskPrio10 (void *pdata)
{
 INT8U err;
 //FILE *des;
 char msg[] = "Soy tarea #1\n";
 char car;
 uint conta = 0,tam;
 tam = SIZE_ARR(msg);
 //printf("Task #1: tam = %d\n",tam);

 pdata = pdata;
// while (1) {
   /*Application code*/
   printf("\nTask #1 Entering Critical Section\n");
   
   /*Access common resource*/
   //if ((des = fopen("/dev/scull","a")) == NULL) {
   //  printf("\nTask #1: NO SE PUDO ABRIR EL DISPOSITIVO\n");
   //  exit(1);
   //}
   //fseek(des, 0L, SEEK_END);
   while (conta <= tam) {
     car = msg[conta++];
     fputc(car,des);
     OSTimeDly(1);
   }
   
   if (conta >= tam) {
     printf("\nTask #1 done.\n");
     //break;
   }
   OSTaskSuspend(OS_PRIO_SELF);
   /*Application code*/
// }
}/*end TaskPrio10()*/

void TaskPrio15 (void *pdata)
{
 INT8U err;
// FILE *des;
 char msg[] = "I am task #2\n";
 char car;
 uint conta = 0,tam;
 tam = SIZE_ARR(msg);

 pdata = pdata;
// while (1) {
   /*Application code*/
   printf("\nTask #2 Entering Critical Section\n");
   
   /*Access common resource*/
   //if ((des = fopen("/dev/scull","a")) == NULL) {
   //  printf("\nTask #2: NO SE PUDO ABRIR EL DISPOSITIVO\n");
   //  exit(1);
   //}
   //fseek(des, 0L, SEEK_END);
   while (conta <= tam) {
     car = msg[conta++];
     fputc(car,des);
     OSTimeDly(1);
   }
   
   if (conta >= tam) {
     printf("\nTask #2 done.\n");
     //break;
   }
   OSTaskSuspend(OS_PRIO_SELF);
   /*Application code*/
// }
}/*end TaskPrio15()*/

void TaskPrio20 (void *pdata)
{
 INT8U err;
// FILE *des;
 char msg[] = "Gnose Itsum #3\n";
 char car;
 uint conta = 0,tam;
 tam = SIZE_ARR(msg);

 pdata = pdata;
// while (1) {
   /*Application code*/
   printf("\nTask #3 Entering Critical Section\n");
   
   /*Access common resource*/
   //if ((des = fopen("/dev/scull","a")) == NULL) {
   //  printf("\nTask #3: NO SE PUDO ABRIR EL DISPOSITIVO\n");
   //  exit(1);
   //}
   //fseek(des, 0L, SEEK_END);
   while (conta <= tam) {
     car = msg[conta++];
     fputc(car,des);
     OSTimeDly(1);
   }
   
   if (conta >= tam) {
     printf("\nTask #3 done.\n");
     //break;
   }
   OSTaskSuspend(OS_PRIO_SELF);
   /*Application code*/
// }
}/*end TaskPrio20()*/


