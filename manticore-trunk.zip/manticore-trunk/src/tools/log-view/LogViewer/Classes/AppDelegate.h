/** \file  AppDelegate.h
 * \author Korei Klein
 * \date 8/12/09
 *
 */

#import <Cocoa/Cocoa.h>

/// The application delegate
/// This class exists to configure things
@interface AppDelegate : NSObject {

}

@end
