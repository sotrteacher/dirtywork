/** \file  DetailInfoView.h
 * \author Korei Klein
 * \date 8/7/09
 *
 */

#import <Cocoa/Cocoa.h>


/// Display inforamation about a detail.
/// This class is to be implemented mostly in interface builder
@interface DetailInfoView : NSView {
}

@end
