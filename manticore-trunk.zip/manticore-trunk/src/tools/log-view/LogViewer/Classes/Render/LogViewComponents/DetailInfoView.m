//
//  DetailInfoView.m
//  LogViewer
//
//  Created by Korei Klein on 8/7/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "DetailInfoView.h"


@implementation DetailInfoView

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code here.
    }
    return self;
}

- (void)drawRect:(NSRect)rect {

}

@end
