/*
 *  LogDataUtils.c
 *  LogViewer
 *
 *  Created by Korei Klein on 8/24/09.
 *  Copyright 2009 __MyCompanyName__. All rights reserved.
 *
 */

#include "LogDataUtils.h"

