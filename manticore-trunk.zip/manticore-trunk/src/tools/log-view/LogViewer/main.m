/** \file  main.m
 * \author Korei Klein
 * \date 8/4/09
 *
 */

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
