#!/bin/sh
	echo '*** EXAMPLE 0 ***'
	cd example0
	make -fmakefile.lin
	make -fmakefile.lin clean
	cd ..
	echo '*** EXAMPLE 1 ***'
	cd example1
	make -fmakefile.lin
	make -fmakefile.lin clean
	cd ..
	echo '*** EXAMPLE 2 ***'
	cd example2
	make -fmakefile.lin
	make -fmakefile.lin clean
	cd ..
	echo '*** EXAMPLE 3 ***'
	cd example3
	make -fmakefile.lin
	make -fmakefile.lin clean
	cd ..
	echo '*** EXAMPLE 4 ***'
	cd example4
	make -fmakefile.lin
	make -fmakefile.lin clean
	cd ..


