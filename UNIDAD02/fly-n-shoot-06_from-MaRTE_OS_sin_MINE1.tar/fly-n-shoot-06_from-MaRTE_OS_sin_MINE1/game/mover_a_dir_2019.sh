#!/bin/sh
cp -v ~/rtos.iso /mnt/c/Users/LMC/2019/
