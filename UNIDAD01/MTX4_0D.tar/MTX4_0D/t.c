/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/
/************* tc.c file ******************/
#include "libepc.h"
#include "descriptor_tables.h"
#include "isr.h"
struct multiboot;    /* In order to avoid compiler warning */
void tswitch(void);  /* In order to avoid compiler warning */
                     /* defined in file tswitch.s */
#define SSIZE  1024

typedef struct proc{
        struct proc *next;
               int  *ksp;
               int   kstack[SSIZE];
}PROC;

PROC proc, *running;
int procSize = sizeof(PROC);

int scheduler()
{ 
  running = &proc;
}
/*
static void interrupt8_callback(registers_t regs)
{
 (void*)&regs;
}
static void interrupt13_callback(registers_t regs)
{
 (void*)&regs;
}
*/

void init_timer() {
    /* If we wanted to set a frequency. */
    /*
    int frequency = 1;
    u32int divisor = 1193180 * frequency;
    u8int l = (u8int)(divisor & 0xFF);
    u8int h = (u8int)( (divisor>>8) & 0xFF );
    */

    /* But we just want the maximum divisor instead. */
    u8int l = 0xFF;
    u8int h = 0xFF;

    /* Command byte. */
    outportb(0x43, 0x36);

    // Send the frequency divisor.
    outportb(0x40, l);
    outportb(0x40, h);
}

   

int main(struct multiboot *mboot_ptr)
{
  // Initialise all the ISRs and segmentation
  init_descriptor_tables();
  
//  register_interrupt_handler(8,(isr_t)&interrupt8_callback);
//  register_interrupt_handler(13,(isr_t)&interrupt13_callback);
  ClearScreen(0x07);
  SetCursorPosition(0,0);
  PutString("PROGRAM 1\r\n");
  PutString("IDTR done?\r\n");
    asm volatile("int $0x3");
    asm volatile("int $0x4");
  PutString("\r\n------------------------------------\r\n");
  __asm__ __volatile__("sti");
  init_timer();
//
//  DWORD32 timeout;
//  timeout = Now_Plus(1);
//  PutString("\r\ntimeout = ");
//  PutUnsigned(timeout,10,0);
//  PutString("\r\n");
//  while (Now_Plus(0) < timeout) { /*do nothing*/ }
//  PutString("\r\n------------------------------------\r\n");
//
  return 0;
}/*end main()*/


