extern unsigned char read_port (int port);
extern void write_port (int port, unsigned char val);
extern void kb_init(void);

