/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/

/********************** kernel.c file ***********************/
int rflag;
int body();
int geti()
{
  char s[16];
  gets(s);
  return atoi(s);
}

PROC *kfork()
{
      PROC *p = get_proc();
      int i;
      if (!p){
          printf("no more PROC, kfork() failed\n");
          return 0;
      }
      p->status = READY;
      p->priority = 1;          // priority = 1 for all proc except P0
      p->ppid = running->pid;   // parent = running
      p->parent = running;

      p->kstack[SSIZE-1] = (int)body;
      for (i=1; i<10; i++)
	  p->kstack[i]= 0 ;
      p->saved_sp = &(p->kstack[SSIZE-9]);
      enqueue(&readyQueue, p);  // enter p into readyQueue by priority
      return p;                 // return child PROC pointer
}         

int do_tswitch()
{
  printf("proc %d tswitch()\n", running->pid);
  tswitch();
  printf("proc %d resumes\n", running->pid);
}

int do_kfork()
{
  PROC *p;
  printf("proc %d kfork a child\n", running->pid);
  p = kfork();
  if (p==0)
    printf("kfork failed\n");
  else
    printf("child pid = %d\n", p->pid);
}

int do_exit()
{
  int i;
  printf("proc %d exit\n", running->pid);
  running->status = FREE;
  put_proc(running);
  tswitch();
}

int do_stop()
{
  printf("proc %d stop running\n", running->pid);
  running->status = STOPPED;
  tswitch();
  printf("proc %d resume from stop\n", running->pid);
}

int do_resume()
{
  PROC *p;
  int pid;
  char s[16];

  printf("enter pid to resume : ");
  pid = geti();

  if (pid < 1 || pid >= NPROC){
     printf("invalid pid\n", pid);
     return 0;
  }
  p = &proc[pid];
  if (p->status == STOPPED){
     p->status = READY;
     enqueue(&readyQueue, p);
     return 1;
  }
  printf("proc %d is NOT in STOPPED state\n", pid);
  return 0;
}

int reschedule()
{
  PROC *p, *tempQ = 0;

  while ( (p=dequeue(&readyQueue)) ){
        enqueue(&tempQ, p);
  }
  readyQueue = tempQ;

  rflag = 0;
  if (running->priority < readyQueue->priority)
    rflag = 1;
}

int chpriority(int pid, int pri)
{
  PROC *p; int i, ok=0, reQ=0;

  if (pid == running->pid){
     running->priority = pri;

     if (pri < readyQueue->priority) 
        rflag = 1;
    return 1;
  }
  // not for running; for both READY and SLEEP procs
  for (i=1; i<NPROC; i++){
    p = &proc[i];
    if (p->pid == pid && p->status != FREE){
      p->priority = pri;
      ok = 1;
      if (p->status == READY)  // in readyQueue==> redo readyQueue
	reQ = 1;
    }
  }
  if (!ok){
    printf("chpriority failed\n");
    return -1;
  }
  if (reQ)
     reschedule(p);
}

int do_chpriority()
{
  int pid, pri;
  char s[16];
  printf("input pid " );
  pid = geti();
  printf("input new priority " );
  pri = geti();
  if (pri<1) 
      pri = 1;
  chpriority(pid, pri);
}

int body()
{
  char c;
  printf("proc %d resumes to body()\n", running->pid);

  while(1){

   if (rflag){
     printf("%d running : but re-schedule flag is on : tswitch()\n", 
             running->pid);
     rflag = 0;
     tswitch();
   }

    printf("-----------------------------------------\n");
    printList("freelist  ", freeList);
    printQ("readyQueue", readyQueue);
    printf("-----------------------------------------\n");

   printf("proc %drunning: priority=%d parent=%d enter a char [s|f|q|t|r|p] : ",
           running->pid, running->priority, running->parent->pid );
    c = getc(); printf("%c\n", c);
    switch(c){
       case 'f' : do_kfork();   break;
       case 's' : do_tswitch(); break;
       case 'q' : do_exit();    break;
       case 't' : do_stop();    break;
       case 'r' : do_resume();  break;
       case 'p' : do_chpriority(); break;
    }
  }
}
