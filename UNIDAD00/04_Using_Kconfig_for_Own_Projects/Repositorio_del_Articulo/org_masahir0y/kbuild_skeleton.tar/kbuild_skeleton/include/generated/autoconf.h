/*
 * Automatically generated C config: don't edit
 * MYAPP Configuration
 */
#define CONFIG_LOGGING_TIME 1
#define CONFIG_ENABLE_LOGGING 1
#define CONFIG_DEFAULT_LOGLEVEL 3
#define CONFIG_CROSS_COMPILE ""
