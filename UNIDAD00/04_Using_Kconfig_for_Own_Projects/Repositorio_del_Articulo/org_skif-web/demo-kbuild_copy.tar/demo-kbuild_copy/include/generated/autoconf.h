/*
 * Automatically generated C config: don't edit
 * Linux Kernel Configuration
 */
#define CONFIG_SELECT_DESTINATION_FILE 1
#define CONFIG_SELECT_DESTINATION_FILE_FILENAME "last.log"
