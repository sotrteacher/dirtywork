/* Skelix by Xiaoming Mo (skelixos@gmail.com)
 * Licence: GPLv2 */
#ifndef KB_H
#define KB_H

void kb_install(void);

#endif
