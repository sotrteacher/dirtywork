int main(){
 return 20;
}
