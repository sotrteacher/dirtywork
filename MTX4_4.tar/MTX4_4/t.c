/********************************************************************
Copyright 2010-2015 K.C. Wang, <kwang@eecs.wsu.edu>
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
********************************************************************/

#include "type.h"

PROC proc[NPROC], *running, *freeList, *readyQueue;
int procSize = sizeof(PROC);
int nproc;
extern int color;

#include "wait.c"
#include "kernel.c"

int init()
{
    PROC *p;
    int i;
    printf("init ....");

    for (i=0; i<NPROC; i++){   // initialize all procs
         p = &proc[i];
         p->pid = i;
         p->status = FREE;
         p->priority = 0;     
         p->next = &proc[i+1];
    }
    freeList = &proc[0];      // all procs are in freeList
    proc[NPROC-1].next = 0;
    readyQueue;

    /**** create P0 as running ******/
    p = get_proc();
    p->status = RUNNING;
    running = p;
    printf("done\n");
} 
            
 main()
{
    printf("MTX starts in main()\n");
    init();          // initialize and create P0 as running
    kfork();         // P0 kfork() P1
    while(1){
       printf("P0 running\n");
       while(!readyQueue);
       printf("P0 switch process\n");
       tswitch();   // P0 switch to run P1
    }
}

int scheduler()
{
    if (running->status == RUNNING){
       running->status = READY;
       enqueue(&readyQueue, running);
    }
    running = dequeue(&readyQueue);
    running->status = RUNNING;
    color = 0x000A + (running->pid % 5);
}
